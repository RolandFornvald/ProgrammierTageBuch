﻿using System.Collections;

namespace DigitSequence.Test;

public sealed class DigitsTests
{
    [Fact]
    public void NegativeValue()
    {
        var digits = new Digits(-350);
        digits.ToString().Should().Be("350", "negative numbers are turned into positive");
    }

    [Fact]
    public void Enumeration()
    {
        var digits = new Digits(220056010);
        int[] digitsArray = { 2, 2, 0, 0, 5, 6, 0, 1, 0 };

        digits.Should<Digits>().BeAssignableTo<IEnumerable<int>>();

        var idx = 0;
        foreach (int digit in digits)
        {
            digit.Should().Be(digitsArray[idx++]);
        }

        digits.GetEnumerator().Should().BeOfType<DigitEnumerator>();
        (digits as IEnumerable).GetEnumerator().Should()
                               .NotBeNull()
                               .And.BeOfType<DigitEnumerator>();
    }

    [Fact]
    public void Comparison()
    {
        var a = new Digits(890);
        var b = new Digits(891);
        var c = new Digits(890);

        a.Should<Digits>().BeAssignableTo<IComparable<Digits>>();

        a.CompareTo(b).Should().BeLessThan(0);
        b.CompareTo(a).Should().BeGreaterThan(0);
        a.CompareTo(a).Should().Be(0);
        b.CompareTo(b).Should().Be(0);
        a.CompareTo(c).Should().Be(0);
        c.CompareTo(a).Should().Be(0);
        a.CompareTo(null).Should().BeGreaterThan(0);
    }

    [Theory]
    [InlineData(123, "123")]
    [InlineData(321, "321")]
    [InlineData(-45, "45")]
    [InlineData(01, "1")]
    [InlineData(10, "10")]
    public void StringRepresentation(int number, string expected)
    {
        var digits = new Digits(number);
        digits.ToString().Should().Be(expected);
    }

    [Fact]
    public void GetEnumerator_NotShared()
    {
        var digits = new Digits(123);

        digits.GetEnumerator().Should()
              .NotBeSameAs(digits.GetEnumerator(), "for each iteration a new enumerator is created");
    }
}
