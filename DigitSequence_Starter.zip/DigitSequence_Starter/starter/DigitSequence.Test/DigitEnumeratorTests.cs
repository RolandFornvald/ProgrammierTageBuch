﻿using System.Collections;

namespace DigitSequence.Test;

public sealed class DigitEnumeratorTests
{
    [Fact]
    public void Simple()
    {
        var enumerator = new DigitEnumerator(123);

        // we cannot check Current value, because it is - according to the spec - currently in an
        // undefined (in the sense of 'any value') state since MoveNext has never been called
        
        enumerator.MoveNext().Should().BeTrue("there are more digits");
        enumerator.Current.Should().Be(1, "the first digit is 1");
        
        enumerator.MoveNext().Should().BeTrue("there are still more digits");
        enumerator.Current.Should().Be(2, "the second digit is 2");
        
        enumerator.MoveNext().Should().BeTrue("there is one more digit");
        enumerator.Current.Should().Be(3, "the third digit is 3");
        
        enumerator.MoveNext().Should().BeFalse("exhausted");
        
        // we cannot check Current value, because it is - according to the spec - now in an
        // undefined (in the sense of 'any value') state since MoveNext returned false
    }

    [Fact]
    public void NegativeNumber()
    {
        var enumerator = new DigitEnumerator(-654);
        
        enumerator.MoveNext().Should().BeTrue("there are more digits");
        enumerator.Current.Should().Be(6, "negative number turned into positive");
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(5);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(4);
        
        enumerator.MoveNext().Should().BeFalse("exhausted");
    }

    [Fact]
    public void SingleDigit()
    {
        var enumerator = new DigitEnumerator(6);
        
        enumerator.MoveNext().Should().BeTrue("one digit present");
        enumerator.Current.Should().Be(6, "the only digit is 6");

        enumerator.MoveNext().Should().BeFalse("no more digits");
    }
    
    [Fact]
    public void SingleDigit_Zero()
    {
        var enumerator = new DigitEnumerator(0);
        
        enumerator.MoveNext().Should().BeTrue("zero is a valid digit");
        enumerator.Current.Should().Be(0, "the only digit is 0");

        enumerator.MoveNext().Should().BeFalse("no more digits");
    }

    [Fact]
    public void ContainsZero()
    {
        var enumerator = new DigitEnumerator(504);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(5);
        
        enumerator.MoveNext().Should().BeTrue("there are still more digits");
        enumerator.Current.Should().Be(0, "zero is a valid digit");
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(4);
        
        enumerator.MoveNext().Should().BeFalse();
    }
    
    [Fact]
    public void ContainsZero_Multiple()
    {
        var enumerator = new DigitEnumerator(5004);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(5);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(0, "zero is a valid digit");
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(0, "zero is a valid digit");
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(4);
        
        enumerator.MoveNext().Should().BeFalse();
    }
    
    [Fact]
    public void ContainsZero_Multiple_EndsWith()
    {
        var enumerator = new DigitEnumerator(500);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(5);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(0, "zero is a valid digit");
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(0, "zero is a valid digit");
        
        enumerator.MoveNext().Should().BeFalse();
    }

    [Fact]
    public void Reset()
    {
        var enumerator = new DigitEnumerator(45678);
        
        enumerator.MoveNext().Should().BeTrue();
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(5);
        
        enumerator.Reset();
        enumerator.MoveNext().Should().BeTrue();
        enumerator.Current.Should().Be(5);

        while (enumerator.MoveNext())
        {
            // loop to end
        }
        
        enumerator.Reset();
        for (var i = 0; i < 3; i++)
        {
            enumerator.MoveNext();
        }

        (enumerator as IEnumerator).Current.Should().NotBeNull()
                                   .And.BeOfType<int>()
                                   .And.Be(7);
    }
}
