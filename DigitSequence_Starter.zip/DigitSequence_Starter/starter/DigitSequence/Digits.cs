﻿using System.Collections;
using System.Globalization;

namespace DigitSequence;

public sealed class Digits : IEnumerable<int>, IComparable<Digits>
{
    // TODO
    private readonly int _number;

    public Digits(int number)
    {
        _number = Math.Abs(number);
        // TODO
    }

    public int CompareTo(Digits? other)
    {
        if(other == null) return 1;
        string nm1 = this.ToString();
        string nm2 = other.ToString();

        return nm1.CompareTo(nm2);
    }

    public IEnumerator<int> GetEnumerator() => new DigitEnumerator(_number); // TODO

    IEnumerator IEnumerable.GetEnumerator() => new DigitEnumerator(_number); // TODO

    public override string ToString() => $"{_number}"; // TODO

}
