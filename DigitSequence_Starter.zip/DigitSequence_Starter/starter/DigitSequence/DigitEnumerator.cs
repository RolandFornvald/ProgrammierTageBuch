﻿using System.Collections;

namespace DigitSequence;

public sealed class DigitEnumerator : IEnumerator<int>
{

    // TODO
    private readonly int _number;
    private int[] _digits = new int[0];
    public DigitEnumerator(int number)
    {

        _number = Math.Abs(number);
        _digits = NumbersIn(_number);
        // TODO
    }

    int _dIndex = -1;
    public bool MoveNext()
    {
        _dIndex++;
        return _dIndex < _digits.Length;
    }

    public void Reset()
    {
        _dIndex = 0;
    }

    public int Current => _digits[_dIndex]; // TODO

    object IEnumerator.Current => Current; // TODO

    public void Dispose()
    {
        // TODO ?
    }
    public int[] NumbersIn(int value)
    {
        var numbers = new Stack<int>();

        if (value == 0) numbers.Push(0);
        else
        {
            for (; value > 0; value /= 10)
                numbers.Push(value % 10);

        }
        return numbers.ToArray();

    }


}
