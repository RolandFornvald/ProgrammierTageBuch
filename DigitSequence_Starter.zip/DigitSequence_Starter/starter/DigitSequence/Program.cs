﻿using System.Text;

Console.OutputEncoding = Encoding.UTF8;

Console.WriteLine("*** DigitSequence ***");